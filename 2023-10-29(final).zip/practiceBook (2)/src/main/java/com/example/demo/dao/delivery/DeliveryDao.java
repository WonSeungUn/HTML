package com.example.demo.dao.delivery;



import org.apache.ibatis.annotations.*;

import com.example.demo.entity.delivery.*;

@Mapper
public interface DeliveryDao {
	@SelectKey(statement = "select delivery_seq.nextval from dual", before = true, resultType = long.class, keyProperty = "dno")
	
	@Insert("insert into delivery values(#{dno}, #{memberId}, #{zipCode}, #{receiverName}, #{deliveryAddress}, #{receiverTel}, '조심히 와주세요', #{defaultAddress}, #{deliveryName})")
	public Long save(Delivery delivery);
	
	@Select("select * from delivery where member_id= #{memberId} and rownum=1")
	public Delivery findDeliveryByDno(String memberId);
	
	@Select("select default_address from delivery where member_id = #{memberId} and rownum=1")
	public Long findDefaultAddress(String memberId);
    
    
    

	
	
	
	
}