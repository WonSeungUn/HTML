package com.example.demo.service.delivery;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import com.example.demo.dao.delivery.*;
import com.example.demo.dao.member.*;
import com.example.demo.dto.delivery.*;
import com.example.demo.entity.delivery.*;
import com.example.demo.entity.member.*;

@Service
public class DeliveryService {
  @Autowired
  private DeliveryDao deliveryDao;
  @Autowired
  private MemberDao memberDao;
  
  // 1. 배송지 추가
  public Boolean deliveryAdd(String memberId, DeliveryDto.Create dto) {
	  Delivery delivery = new Delivery(null, memberId, dto.getZipCode(), dto.getReceiverName(), dto.getDeliveryAddress(), dto.getDefaultAddress(), dto.getReceiverTel(), null, dto.getDeliveryName());
	  Long defaultAddress = deliveryDao.findDefaultAddress(memberId);
	  if(defaultAddress == 1L) {
		  delivery.setDefaultAddress(0L);
	  }
	  return deliveryDao.save(delivery) == 1;
  }
  
  // 2. 배송지 목록
  public DeliveryDto.Read read(String memberId) {
	  Member member = memberDao.findById(memberId);
	  Delivery delivery = deliveryDao.findDeliveryByDno(member.getMemberId());
	  if(delivery == null) {
		  return null;
	  }
	  return new DeliveryDto.Read(delivery.getReceiverName(), delivery.getDeliveryName(), delivery.getDefaultAddress(), delivery.getReceiverTel(), delivery.getZipCode(), delivery.getDeliveryAddress());
	  
	  
  }
}