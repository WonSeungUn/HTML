package com.example.demo;

import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

import org.springframework.security.access.*;
import org.springframework.security.web.access.*;
import org.springframework.stereotype.*;

// 1. 스프링 시큐리티는 인증과 인가 서비스를 제공
// - 인증 : 사용자의 신원을 확인. 주로 로그인
// - 인가 : 사용자의 권한을 확인

// 2. 인증과 인가 확인에 실패하면 403 오류가 발생한다
//    스프링 시큐리티에서 403 처리를 담당하는 표준은 AccessDeniedHandler 인터페이스  

// 3. 403은 MVC와 REST 모두에서 발생한다
// - MVC라면 이동하자
//   루트 페이지로 이동해서 오류메시지를 출력
// - REST에 대한 ajax요청이라면 이동하지 않는다
//   403이라고 쏴주자(여기는 스프링 컨트롤러가 아니므로 response 객체를 이용해 403을 출력한다)
// - 문제점은? 요청 방식이 mvc인지 ajax인지 구별해야 한다

// 4. request 객체, response 객체는 header와 body로 구성된다
// - 비유하자면 편지는 편지지(body)와 편지봉투(header)로 구성된다
// - ajax 방식 요청인 경우 "X-Requested-With"란 헤더의 값이 "XMLHttpRequest"로 설정된다
// - ajax 방식 요청이 아닌 경우 "X-Requested-With"란 헤더의 값이 null

@Component
public class MyAccessDeniedHandler implements AccessDeniedHandler {
	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException, ServletException {
		// X-Requested-With 헤더의 값을 가져온다
		String ajax = request.getHeader("X-Requested-With");
		Boolean isAjax = ajax!=null && ajax.equals("XMLHttpRequest");
		
		// ajax라면 403을 쏴주고 아니면 이동한다
		// (여긴 컨트롤러가 아니므로 servlet 방식으로 출력)
		if(isAjax) {
			response.sendError(403);
		} else {
			response.sendRedirect("/?error");
		}
	}
}
